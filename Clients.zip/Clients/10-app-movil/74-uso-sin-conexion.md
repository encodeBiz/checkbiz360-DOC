# Uso sin conexión

CheckBiz360 está diseñado para funcionar principalmente con conexión a internet, ya que muchas de sus operaciones críticas requieren validación en tiempo real con los servidores. Sin embargo, la aplicación incluye un modo sin conexión limitado que le permite seguir consultando cierta información cuando no dispone de acceso a internet. Este artículo explica qué funciona sin conexión, qué no está disponible y cómo gestionar la sincronización cuando se restablece la conectividad.

---

## Que funciona sin conexión

Cuando la aplicación detecta que no hay conexión a internet disponible, activa automáticamente el modo sin conexión. En este estado, puede acceder a la información que ya fue descargada y almacenada en la caché del dispositivo durante sesiones anteriores con conexión activa:

### Consultar registros de asistencia ya descargados

Puede revisar el historial de fichajes que fue descargado en sesiones anteriores. La información mostrada corresponde al último estado sincronizado con el servidor; no verá cambios posteriores a la última sincronización.

### Consultar documentos en caché

Los documentos laborales que ya abrió o descargó previamente mientras tenía conexión permanecen disponibles para su consulta sin conexión. Esto incluye nóminas, contratos u otros archivos que haya abierto desde la sección de documentos.

### Consultar tareas descargadas

Las tareas que fueron cargadas durante la última sesión con conexión pueden consultarse en modo sin conexión. Podrá ver el detalle de cada tarea, sus archivos adjuntos descargados y su estado en el momento de la última sincronización.

---

## Que NO funciona sin conexión

Las siguientes funciones requieren obligatoriamente conexión a internet y no están disponibles en modo sin conexión:

### Realizar fichajes

El registro de asistencia (check-in, check-out y pausas) requiere validación en tiempo real con el servidor de CheckBiz360. El sistema necesita verificar su identidad, su ubicación GPS en relación con el radio permitido y el estado de su turno activo en el momento exacto del fichaje.

> **Aviso:** Si intenta realizar un fichaje sin conexión, la aplicación le informará de que no es posible completar la operación en ese momento. No almacene un intento de fichaje para enviarlo después, ya que la marca de tiempo del fichaje debe corresponder al momento real en que este se produce.

### Descargar nuevos documentos

Si su organización publica un nuevo documento mientras usted no tiene conexión, no podrá descargarlo ni visualizarlo hasta que recupere el acceso a internet.

### Sincronizar cambios de estado de tareas

Si intenta marcar una tarea como completada o actualizar su estado sin conexión, el cambio se guardará localmente pero no se transmitirá al servidor hasta que se restablezca la conectividad.

### Iniciar sesión por primera vez en el dispositivo

El proceso de autenticación inicial siempre requiere conexión para verificar las credenciales contra el servidor. Si nunca ha iniciado sesión en ese dispositivo, no podrá acceder a la aplicación sin conexión.

---

## Sincronización automática al recuperar la conexión

Cuando CheckBiz360 detecta que la conexión a internet se ha restablecido, realiza de forma automática una sincronización en segundo plano:

1. Se envían al servidor los cambios de estado de tareas que quedaron pendientes.
2. Se descarga la información actualizada de registros, documentos y tareas.
3. La aplicación muestra una notificación o indicador visual cuando la sincronización se ha completado correctamente.

No es necesario que realice ninguna acción manual para iniciar este proceso; ocurre automáticamente en cuanto se detecta la conexión. No obstante, si desea forzar una sincronización inmediata, puede hacerlo accediendo a cualquier sección de la aplicación o deslizando hacia abajo en la pantalla para actualizar el contenido.

---

## Recomendaciones para entornos con conectividad intermitente

Si trabaja habitualmente en entornos donde la conexión a internet no es estable o desaparece con frecuencia, tenga en cuenta las siguientes recomendaciones:

1. **Realice sus fichajes en el momento en que sí dispone de conexión.** No espere a que la conexión sea perfecta; si tiene señal suficiente, realice el fichaje de inmediato.
2. **Abra los documentos con antelación.** Si sabe que necesitará consultar un documento, ábralo cuando disponga de conexión para que quede almacenado en la caché del dispositivo.
3. **Revise las tareas antes de perder la conexión.** Cargue el listado de tareas cuando tenga conexión para que la información esté disponible cuando no la tenga.
4. **Active el WiFi cuando esté disponible.** Una conexión WiFi estable es preferible a los datos móviles en entornos con cobertura fluctuante.
5. **Comunique los problemas de conectividad a su manager.** Si los problemas de conexión afectan de forma recurrente a sus fichajes, informe a su manager para que quede constancia y puedan tomarse las medidas oportunas.

> **Aviso:** Si un día no pudo realizar ningún fichaje por problemas de conectividad, debe informar a su manager y, si corresponde, solicitar el alta de una jornada manual desde la sección "Mis registros". Consulte el artículo sobre registros de asistencia para conocer el procedimiento completo.

---

## Nota de rol

Este artículo está dirigido a **empleados** que utilizan la app en entornos donde la conectividad puede ser limitada o intermitente. Los administradores pueden configurar desde el panel web los parámetros de validación de fichajes para adaptarlos a entornos de baja conectividad.

---

## Artículos relacionados

- [Mis registros de asistencia](73-mis-registros-de-asistencia.md)
- [Navegación principal de la app](71-navegacion-principal-de-la-app.md)
- [Actualizaciones de la app](75-actualizaciones-de-la-app.md)
