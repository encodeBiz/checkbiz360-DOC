# Configurar preferencias de notificación

CheckBiz360 permite ajustar qué notificaciones recibe cada usuario según su rol y sus necesidades operativas. Los empleados pueden gestionar sus preferencias desde la app móvil; los responsables pueden configurar qué alertas reciben ellos mismos y, en algunos casos, qué notificaciones se envían a los miembros de su equipo. Este artículo describe las opciones de configuración disponibles para cada perfil y las notificaciones que nunca pueden desactivarse.

## Preferencias que gestiona el empleado desde la app

El empleado puede acceder a su configuración de notificaciones desde la app siguiendo estos pasos:

1. Abra la app CheckBiz360 en su dispositivo.
2. Pulse sobre su avatar o nombre en la esquina superior de la pantalla principal para acceder a su perfil.
3. Seleccione **Preferencias** o **Configuración de notificaciones**.
4. Encontrará una lista de tipos de notificación con un interruptor individual para cada uno.

### Notificaciones que el empleado puede activar o desactivar

| Notificación | Descripción | Activada por defecto |
|---|---|---|
| Nuevo documento disponible | Aviso cuando se asigna un nuevo documento para consulta | Sí |
| Recordatorio de firma pendiente | Recordatorio periódico de documentos sin firmar | Sí |
| Nueva tarea asignada | Aviso cuando el responsable asigna una nueva tarea | Sí |
| Recordatorio de vencimiento de tarea | Alerta antes de que venza una tarea | Sí |
| Tarea validada o rechazada | Resultado de la validación de una tarea completada | Sí |
| Jornada aprobada o rechazada | Resultado de una solicitud de jornada manual | Sí |
| Recordatorio de fichaje de salida | Aviso al acercarse la hora de fin de turno si no ha fichado salida | No |

> **Aviso:** Los cambios en las preferencias de notificación se aplican de forma inmediata. Si el empleado desactiva los recordatorios de firma pendiente, no recibirá avisos de documentos sin firmar aunque la fecha límite esté próxima. Es responsabilidad del empleado gestionar sus preferencias con criterio.

## Preferencias que gestiona el responsable desde el backoffice

Los roles Manager y Supervisor pueden configurar desde el backoffice qué alertas relacionadas con su equipo reciben en su propio centro de notificaciones. El acceso se realiza desde:

1. **Configuración** > **Mis preferencias de notificación** en el menú del perfil del responsable.

### Notificaciones que el responsable puede configurar para sí mismo

| Notificación | Descripción |
|---|---|
| Empleado que no ha fichado | Recibir alerta cuando un empleado de su equipo no ha registrado entrada |
| Jornada manual pendiente de aprobación | Aviso de solicitudes de jornada que requieren su validación |
| Documento firmado | Confirmación cuando un empleado firma un documento |
| Tarea completada | Aviso cuando un empleado marca una tarea como terminada |
| Fichaje sospechoso | Alerta cuando el sistema detecta un fichaje irregular en su equipo |

Además, desde la ficha de cada sucursal, el Manager puede configurar qué Supervisores de esa sucursal reciben cada tipo de alerta operativa. Esto permite distribuir la carga de notificaciones entre varios responsables sin que todos reciban las mismas alertas.

## Notificaciones que no se pueden desactivar

Las siguientes notificaciones están bloqueadas de forma permanente y no pueden desactivarse desde ningún perfil ni rol:

### Alertas de seguridad críticas

- **Dispositivo no autorizado**: intento de fichaje desde un dispositivo no reconocido para el empleado.
- **Acceso desde ubicación inusual**: inicio de sesión en el backoffice desde una IP o localización diferente a la habitual.
- **Intentos de acceso fallidos repetidos**: múltiples intentos consecutivos de acceder a una cuenta.
- **Fichaje sospechoso de alto riesgo**: fichaje que supera los umbrales de severidad máxima del motor de análisis.

Estas notificaciones no son configurables porque su desactivación comprometería la seguridad de la plataforma. Su recepción está garantizada por el sistema independientemente de las preferencias del usuario.

> **Aviso:** Si recibe una alerta de seguridad crítica, revise el evento con atención antes de descartarla. Si no reconoce la actividad descrita, contacte con el soporte de CheckBiz360 de inmediato.

## Canal de respaldo por email

Cuando un dispositivo no recibe correctamente una notificación push (dispositivo apagado, sin conexión, permisos denegados), el sistema dispone de un mecanismo de respaldo que envía determinadas notificaciones también por correo electrónico. Este canal de respaldo se activa automáticamente para los siguientes tipos:

- Recordatorio de firma pendiente (si han transcurrido 48 horas sin que el empleado abra la notificación push).
- Alerta de seguridad crítica.
- Jornada manual rechazada.
- Invitación de nueva cuenta (siempre se envía por email como canal principal).

El canal de respaldo por email no es configurable de forma individual; actúa de forma automática como garantía de entrega para los eventos más importantes. La dirección de remitente es `hola@encodebiz.com`.

## Restablecer las preferencias por defecto

Si necesita restablecer la configuración de notificaciones a los valores originales:

**Desde la app (empleado):**
1. Acceda a su perfil > **Preferencias** > **Configuración de notificaciones**.
2. Pulse **Restablecer valores por defecto** al final de la lista.
3. Confirme la operación.

**Desde el backoffice (responsable):**
1. Acceda a **Configuración** > **Mis preferencias de notificación**.
2. Pulse **Restablecer** y confirme.

---

> **Nota de rol:** El empleado (**Worker**) gestiona sus preferencias desde la app. El **Manager** y el **Supervisor** gestionan las suyas desde el backoffice y pueden configurar la distribución de alertas entre los supervisores de su equipo. El **Owner** recibe todas las alertas críticas y administrativas de la entidad de forma consolidada y no puede reducir este conjunto de notificaciones.

## Artículos relacionados

- [Tipos de notificación](63-tipos-de-notificacion.md)
- [Notificaciones push en la app](64-notificaciones-push-en-la-app.md)
- [Alertas para responsables](66-alertas-para-responsables.md)
- [Notificaciones por email](68-notificaciones-por-email.md)
