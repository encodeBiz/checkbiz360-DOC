# Historial de notificaciones

CheckBiz360 conserva un registro completo de todas las notificaciones enviadas a cada usuario. Este historial permite verificar si una notificación fue enviada y entregada, consultar eventos pasados y, en el caso de los responsables, comprobar que los empleados han recibido comunicaciones importantes como avisos de documentos pendientes de firma. Este artículo describe dónde consultar el historial y qué información proporciona.

## Historial de notificaciones en la app (empleados)

Los empleados pueden consultar todas las notificaciones que han recibido directamente desde la app CheckBiz360:

1. Abra la app y pulse el icono de campana o de notificaciones en la barra superior de la pantalla principal.
2. Se abrirá la lista de notificaciones recibidas, ordenadas cronológicamente de más reciente a más antigua.
3. Pulse sobre cualquier notificación para ver su detalle completo y, si la acción sigue disponible, acceder al recurso asociado.

### Información disponible en cada notificación

Cada entrada del historial muestra:

- **Tipo de notificación**: categoría e identificador del evento (por ejemplo, "Firma pendiente" o "Tarea asignada").
- **Descripción**: texto completo de la notificación tal como se recibió.
- **Fecha y hora de envío**: momento exacto en que el sistema generó y envió la notificación.
- **Estado de lectura**: indicador visual que distingue entre notificaciones leídas (sin marca) y no leídas (marcadas en negrita o con un punto de color).

Las notificaciones no leídas se destacan visualmente para facilitar su identificación. Pulsar sobre una notificación la marca automáticamente como leída.

### Marcar como leídas y limpiar el historial

Desde la pantalla de notificaciones, el empleado puede:

- **Marcar todas como leídas**: elimina el indicador de no leídas de todas las notificaciones del listado de una sola vez.
- **Eliminar notificaciones individuales**: deslizando la notificación hacia la izquierda (en iOS) o manteniéndola pulsada (en Android) aparece la opción de eliminar. La eliminación es solo visual; el registro en el sistema se conserva.

## Historial de notificaciones en el backoffice (responsables)

Los roles Manager, Supervisor y Owner disponen de un historial de notificaciones más detallado en el backoffice web, que incluye no solo las notificaciones propias sino también las enviadas a los miembros de su equipo.

### Acceso al historial en el backoffice

1. Acceda al backoffice web e inicie sesión.
2. Pulse el icono de campana en la barra superior para ver las notificaciones recientes.
3. Al final del panel de notificaciones, pulse **Ver todo el historial** para acceder al historial completo.
4. Alternativamente, navegue a **Configuración** > **Historial de notificaciones**.

### Información disponible en el historial del backoffice

El historial del backoffice incluye campos adicionales respecto al de la app:

| Campo | Descripción |
|---|---|
| Tipo | Categoría de la notificación |
| Destinatario | Nombre y rol del usuario que recibió la notificación |
| Sucursal | Sucursal a la que está vinculado el evento |
| Fecha y hora de envío | Momento exacto de envío por parte del servidor |
| Estado de entrega | Indica si la notificación fue entregada al dispositivo |
| Estado de lectura | Indica si el destinatario abrió la notificación |

### Filtros disponibles

El historial del backoffice puede filtrarse por:

- **Tipo de notificación**: para consultar únicamente un tipo específico.
- **Destinatario**: para ver el historial de un empleado concreto.
- **Periodo**: por fecha de envío, con filtros predefinidos (hoy, esta semana, este mes) y rango personalizado.
- **Estado**: filtrar solo las notificaciones no entregadas o no leídas.

## Cuánto tiempo se conserva el historial

El historial de notificaciones se conserva durante un periodo de **90 días** a contar desde la fecha de envío. Transcurrido ese plazo, las notificaciones se eliminan automáticamente del historial visible. Los datos subyacentes (los eventos que generaron las notificaciones) siguen siendo accesibles a través de los informes y los registros de auditoría, pero no desde la sección de notificaciones.

> **Aviso:** Si necesita conservar evidencia del envío y recepción de una notificación más allá de los 90 días (por ejemplo, para demostrar que un empleado fue notificado de un documento que debía firmar), exporte el historial antes de que expire el plazo. El botón **Exportar historial** en la pantalla de historial del backoffice genera un archivo CSV con todos los registros del periodo seleccionado.

## Caso de uso: verificar que un empleado recibió la notificación de un documento

Uno de los casos de uso más habituales del historial es verificar que el empleado recibió correctamente la notificación de un documento pendiente de firma. El proceso es el siguiente:

1. Acceda al backoffice y navegue al historial de notificaciones.
2. Filtre por tipo **"Firma pendiente"** y por el nombre del empleado en cuestión.
3. Localice la notificación correspondiente al documento de interés.
4. Compruebe el estado de entrega y de lectura.

Si el estado de entrega es "No entregada", es posible que el empleado no tuviera conexión en el momento del envío o que los permisos de notificación estuvieran desactivados. En ese caso, puede reenviar la notificación desde la ficha del documento o contactar con el empleado por otro canal.

Si el estado es "Entregada" pero "No leída", el empleado recibió la notificación en su dispositivo pero no la ha abierto. En ese caso, puede enviar un recordatorio manual desde el backoffice.

---

> **Nota de rol:** El empleado (**Worker**) consulta únicamente sus propias notificaciones desde la app. El **Supervisor** y el **Manager** tienen acceso al historial de notificaciones de los empleados de su equipo desde el backoffice. El **Owner** puede consultar el historial completo de toda la entidad.

## Artículos relacionados

- [Tipos de notificación](63-tipos-de-notificacion.md)
- [Notificaciones push en la app](64-notificaciones-push-en-la-app.md)
- [Configurar preferencias de notificación](65-configurar-preferencias-de-notificacion.md)
- [Alertas para responsables](66-alertas-para-responsables.md)
- [Notificaciones por email](68-notificaciones-por-email.md)
