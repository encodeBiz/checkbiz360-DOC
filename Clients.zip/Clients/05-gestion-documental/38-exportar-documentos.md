# Exportar documentos

CheckBiz360 permite descargar los documentos almacenados en el módulo documental tanto de forma individual como mediante exportaciones agrupadas por empleado, periodo o tipo de documento. Esta funcionalidad es especialmente útil para auditorías de RRHH, entregas a gestoría externa, requerimientos de la Inspección de Trabajo y procesos de archivo físico.

## Descarga individual de documentos

La forma más directa de obtener un documento es descargarlo individualmente desde el backoffice:

1. Acceda a la sección **Documentos** del backoffice.
2. Use los filtros de búsqueda para localizar el documento que desea descargar: por empleado, por categoría, por fecha o por título.
3. Abra el detalle del documento pulsando sobre él.
4. Pulse el botón **Descargar** para guardar el archivo en su dispositivo.

El archivo se descarga en el mismo formato en que fue subido originalmente, habitualmente PDF. El nombre del archivo descargado refleja el título del documento registrado en la plataforma.

## Descarga masiva

Cuando necesita descargar varios documentos a la vez, CheckBiz360 permite agrupar la exportación por diferentes criterios:

### Por empleado

Puede obtener todos los documentos asociados a un empleado concreto. Esto es útil cuando un empleado causa baja en la empresa y necesita preparar su expediente completo, o cuando necesita entregar la documentación de un trabajador a su representante legal.

### Por periodo

Puede filtrar los documentos por fecha de subida y descargar todos los correspondientes a un mes o trimestre concreto. Este tipo de exportación es habitual para cierres contables o para preparar la documentación de un periodo ante una auditoría.

### Por tipo o categoría

Puede descargar todos los documentos de una categoría específica —por ejemplo, todas las nóminas de un año natural— sin importar a qué empleado correspondan. Esto facilita la entrega de documentación clasificada a la gestoría o el archivo físico organizado por tipo documental.

> **Nota:** La disponibilidad de la descarga masiva depende de la configuración de su plan. Si no encuentra la opción de exportación agrupada en su backoffice, consulte con su responsable de cuenta qué opciones están incluidas en su suscripción.

## Formatos disponibles

Los documentos se descargan en el formato original en que fueron subidos al sistema. CheckBiz360 acepta y conserva los archivos en:

- **PDF**: el formato recomendado para garantizar la integridad visual del documento en cualquier dispositivo.
- **Imágenes** (JPG, PNG): documentos escaneados u otros archivos gráficos subidos en estos formatos.

En las exportaciones masivas, los archivos se agrupan habitualmente en un paquete comprimido que puede descargarse de una sola vez.

## Usos típicos de la exportación

### Auditoría de RRHH

Las auditorías internas o externas de RRHH requieren con frecuencia acreditar que se han distribuido correctamente determinados documentos a los empleados —nóminas, contratos, actualizaciones de condiciones— y que los empleados los han recibido. La exportación de documentos combinada con el registro de firma permite generar esta evidencia de forma ordenada.

### Entrega a gestoría

Si su empresa trabaja con una gestoría externa para la gestión laboral, puede exportar periódicamente los documentos almacenados en CheckBiz360 para mantener el archivo de la gestoría actualizado. El criterio habitual es una exportación mensual por empleado o por tipo documental.

### Requerimiento de la Inspección de Trabajo

Ante un requerimiento de la Inspección de Trabajo, es habitual tener que aportar documentación que acredite la entrega de nóminas, contratos vigentes y modificaciones de condiciones. CheckBiz360 permite exportar estos documentos con la trazabilidad de firma asociada, lo que facilita la respuesta al requerimiento dentro de los plazos establecidos.

## Consideraciones sobre protección de datos (LOPD / RGPD)

Los documentos laborales contienen datos personales de los empleados y están sujetos a las obligaciones del Reglamento General de Protección de Datos (RGPD) y a la Ley Orgánica de Protección de Datos y garantía de los derechos digitales (LOPD-GDD).

Al exportar documentación, tenga en cuenta lo siguiente:

- Descargue únicamente los documentos que sean estrictamente necesarios para el fin que justifica la exportación. El principio de minimización de datos del RGPD se aplica también a las operaciones internas de gestión documental.
- Custodie los archivos descargados en sistemas con las medidas de seguridad adecuadas. Un PDF de nóminas descargado en un dispositivo sin cifrado o en un correo electrónico sin restricciones de acceso representa un riesgo para los derechos del empleado.
- Si entrega documentos a terceros —gestoría, representante legal, organismos públicos— asegúrese de que existe una base legal que justifique esa cesión de datos, tal como lo exige el artículo 6 del RGPD.
- Los documentos exportados para responder a requerimientos de la Inspección de Trabajo o de otros organismos públicos tienen cobertura legal propia, pero documente internamente el motivo y el destinatario de cada exportación.

> **Importante:** Si su empresa tiene designado un Delegado de Protección de Datos (DPD), consulte con él los procedimientos internos para la gestión y exportación de documentación laboral antes de establecer flujos de trabajo que impliquen la transferencia de datos personales a terceros.

## Artículos relacionados

- [Qué es el módulo documental](30-que-es-el-modulo-documental.md)
- [Subir y organizar documentos](31-subir-y-organizar-documentos.md)
- [Nóminas y contratos](32-nominas-y-contratos.md)
- [Permisos de acceso documental](37-permisos-de-acceso-documental.md)
- [Documentos privados](33-documentos-privados.md)
- [Historial de versiones](36-historial-de-versiones.md)
