# Firma electrónica

CheckBiz360 permite solicitar la firma electrónica del empleado sobre documentos laborales directamente desde la app móvil. Este mecanismo facilita la acreditación del acuse de recibo y la conformidad del empleado con el contenido del documento, dejando un registro trazable de quién firmó, cuándo y desde qué dispositivo.

## Cómo solicitar la firma al empleado

La solicitud de firma se configura en el momento de subir el documento. El proceso es el siguiente:

1. Acceda al backoffice y cree un nuevo documento o edite uno existente.
2. Active la opción **Requiere firma** en el formulario del documento.
3. Asegúrese de que el documento no está marcado como privado, ya que el empleado necesita verlo para poder firmarlo.
4. Publique el documento. Si ha activado la notificación push, el empleado recibirá un aviso indicando que tiene un documento pendiente de firma.

Una vez publicado, el documento aparece en la app del empleado con un indicador visual que señala que está pendiente de firma.

## Proceso de firma desde la app

Cuando el empleado accede al documento desde su app, puede leer el contenido completo antes de firmar. En la parte inferior de la pantalla de detalle del documento aparecen las opciones disponibles:

- **Firmar**: el empleado confirma que ha leído el documento y presta su conformidad. La firma queda registrada con la fecha, hora y datos del dispositivo.
- **Rechazar**: el empleado indica expresamente que no acepta el contenido del documento o se niega a firmarlo. El rechazo también queda registrado con la misma trazabilidad que la firma.

> **Nota:** La firma en CheckBiz360 es de tipo electrónico simple y equivale a un acuse de recibo con conformidad dentro del sistema. Para documentos que requieran firma electrónica cualificada con certificado digital reconocido, consulte con su asesoría jurídica la conveniencia de complementar el proceso con un servicio de firma certificada externo.

## Estados del documento respecto a la firma

Un documento con la opción de firma activada puede encontrarse en uno de estos tres estados:

| Estado | Descripción |
|---|---|
| Pendiente de firma | El documento ha sido publicado y el empleado aún no ha actuado sobre él. |
| Firmado | El empleado ha firmado el documento. Queda registrada la fecha y hora de la firma. |
| Rechazado | El empleado ha rechazado expresamente firmar el documento. Queda registrado el rechazo con fecha y hora. |

El gestor puede consultar el estado de firma de cada documento desde el backoffice, en el detalle del documento o en la vista de listado, donde se muestran los indicadores de estado.

## Trazabilidad de la firma

Cuando un empleado firma un documento, el sistema registra automáticamente:

- **Quién firmó**: nombre e identificador del empleado dentro de la plataforma.
- **Cuándo se firmó**: fecha y hora exactas de la acción.
- **Estado de la firma**: firmado o rechazado.

Esta información queda almacenada en el historial del documento y es consultable por los gestores con acceso al backoffice. No es editable ni eliminable de forma individual, lo que garantiza la integridad del registro.

> **Importante:** La trazabilidad de firma es un registro interno de la plataforma CheckBiz360. Su validez como prueba documental en procedimientos legales dependerá de factores adicionales, como la autenticación del empleado en el sistema y las condiciones del contrato de servicio. Consulte con su asesoría jurídica si necesita aclarar el valor probatorio en un contexto específico.

## Validez legal de la firma electrónica en España

El Reglamento europeo eIDAS (Reglamento UE 910/2014) establece tres niveles de firma electrónica: simple, avanzada y cualificada. La firma electrónica simple, como la implementada en CheckBiz360, tiene validez legal en contratos y comunicaciones laborales en tanto en cuanto exista una vinculación identificable entre la firma y el firmante.

Para la mayoría de los documentos laborales habituales —nóminas, circulares, acuerdos de horario, comunicaciones internas— la firma electrónica simple es suficiente para acreditar la recepción y conformidad del empleado.

Para actos que requieren firmado con certificado reconocido —como determinadas extinciones contractuales o documentos notariales— es necesario un nivel de firma cualificada que excede el alcance de esta funcionalidad.

## Qué ocurre si el empleado rechaza firmar

Si el empleado rechaza firmar el documento, el sistema registra el rechazo con fecha y hora. El gestor recibe visibilidad de este estado desde el backoffice y puede tomar las medidas que considere oportunas.

El rechazo de firma no elimina el documento ni lo oculta al empleado: el documento sigue accesible para que el empleado pueda consultarlo. El gestor puede editar el documento, si procede, y solicitar una nueva firma.

En caso de que sea necesario documentar el rechazo como parte de un proceso disciplinario o de una comunicación formal, se recomienda complementar el registro de la plataforma con las actuaciones correspondientes según el protocolo interno de la empresa.

## Artículos relacionados

- [Qué es el módulo documental](30-que-es-el-modulo-documental.md)
- [Subir y organizar documentos](31-subir-y-organizar-documentos.md)
- [Nóminas y contratos](32-nominas-y-contratos.md)
- [Documentos privados](33-documentos-privados.md)
- [Notificaciones de documentos](34-notificaciones-de-documentos.md)
- [Historial de versiones](36-historial-de-versiones.md)
