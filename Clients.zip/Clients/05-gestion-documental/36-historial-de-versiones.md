# Historial de versiones

CheckBiz360 mantiene un historial de versiones para los documentos que son actualizados después de su publicación inicial. Esto permite conservar un registro completo de los cambios realizados sobre un documento a lo largo del tiempo, sin perder las versiones anteriores ni el rastro de quién las generó.

El control de versiones es especialmente útil en documentos que se modifican de forma recurrente o que tienen un ciclo de vida largo, como los contratos laborales.

## Cuándo se crea una nueva versión

Una nueva versión de un documento se genera cuando un gestor con los permisos adecuados actualiza el archivo adjunto de un documento existente. El sistema conserva el archivo anterior como versión histórica y establece el nuevo archivo como la versión actual.

Los cambios que crean una nueva versión son:

- Sustitución del archivo adjunto del documento por una versión corregida o actualizada.
- Actualización del contenido cuando el sistema registra el cambio como una nueva revisión del documento.

Los cambios en los metadatos del documento —como el título, la descripción o la categoría— no crean necesariamente una nueva versión del archivo, aunque sí quedan registrados en el sistema con la fecha y el usuario que realizó la modificación.

## Casos de uso habituales

### Contrato modificado

Cuando se modifica un contrato laboral —por una subida de salario, un cambio de categoría profesional o una modificación de jornada— lo habitual es no crear un documento nuevo independiente, sino actualizar el documento de contrato existente con el nuevo archivo. Esto mantiene todo el historial contractual del empleado en un único lugar y facilita la consulta de la evolución de las condiciones laborales a lo largo del tiempo.

### Nómina con corrección

Si se detecta un error en una nómina ya publicada —un descuento incorrecto, una incidencia no reflejada— el gestor puede subir la nómina corregida como una nueva versión del documento existente, en lugar de crear un documento nuevo. El empleado verá la versión actualizada como la vigente y, si se envía una nueva notificación, recibirá el aviso con el documento corregido.

### Certificado renovado

Los certificados de empresa o de situación de IT tienen una vigencia determinada. Cuando se emite un certificado actualizado, puede gestionarse como una versión nueva del certificado anterior o como un documento independiente, según la organización interna que prefiera su empresa.

## Cómo consultar versiones anteriores

Para consultar el historial de versiones de un documento:

1. Acceda al backoffice y navegue hasta la sección **Documentos**.
2. Localice el documento que desea consultar.
3. Abra el detalle del documento.
4. En la sección de historial o versiones, verá la lista de versiones ordenadas por fecha de creación, de más reciente a más antigua.
5. Pulse sobre cualquier versión anterior para visualizar o descargar el archivo correspondiente.

El empleado, desde la app, solo ve la versión vigente del documento. Las versiones anteriores son accesibles únicamente desde el backoffice, por parte de los gestores con los permisos adecuados.

> **Nota:** La consulta de versiones anteriores no restaura la versión antigua como la activa. Para hacer eso, sería necesario subir el archivo de la versión antigua como una nueva actualización del documento.

## Diferencia entre versiones y documentos independientes

Esta es una distinción importante para mantener el archivo documental organizado.

**Versiones** son revisiones del mismo documento: el nombre, la categoría, el empleado destinatario y el propósito son los mismos, pero el contenido del archivo ha cambiado. Ejemplo: contrato del empleado, actualizado en tres ocasiones a lo largo de su relación laboral. Tiene sentido gestionarlo como un único documento con tres versiones.

**Documentos independientes** son archivos que, aunque sean del mismo tipo o periodo, corresponden a realidades distintas. Ejemplo: si un empleado tiene dos relaciones laborales diferenciadas con la empresa en periodos distintos, los contratos de cada periodo deberían ser documentos independientes, no versiones del mismo.

Una buena regla práctica es preguntarse: ¿este nuevo archivo sustituye al anterior o lo complementa? Si lo sustituye, es una nueva versión. Si lo complementa, es un documento independiente.

> **Importante:** Crear documentos independientes en lugar de versiones cuando el documento es el mismo no es un error grave, pero dificulta la trazabilidad a largo plazo y puede complicar la consulta del historial documental del empleado. Establezca una convención interna desde el principio y aplíquela de forma consistente.

## Artículos relacionados

- [Qué es el módulo documental](30-que-es-el-modulo-documental.md)
- [Subir y organizar documentos](31-subir-y-organizar-documentos.md)
- [Nóminas y contratos](32-nominas-y-contratos.md)
- [Firma electrónica](35-firma-electronica.md)
- [Permisos de acceso documental](37-permisos-de-acceso-documental.md)
- [Exportar documentos](38-exportar-documentos.md)
