# Informes de tareas

El módulo de informes de tareas en CheckBiz360 convierte los datos de ejecución en métricas accionables para evaluar el rendimiento del equipo y tomar decisiones operativas fundamentadas. Los responsables pueden acceder a estos informes desde el backoffice en cualquier momento, filtrarlos por diferentes dimensiones y exportarlos para su análisis externo.

---

## Dónde encontrar los informes

Los informes de tareas están disponibles en la sección **Informes** del backoffice, dentro del apartado **Tareas**. El acceso está disponible para managers y owners. Los supervisores pueden acceder a los informes de las sucursales que tienen asignadas, pero no a los datos del resto de la organización.

---

## Métricas disponibles

### Tasa de completitud

La tasa de completitud mide el porcentaje de tareas que han sido completadas (o validadas) respecto al total de tareas creadas en un periodo determinado. Puede calcularse a tres niveles:

**Por empleado:** Permite identificar qué trabajadores completan sus tareas de forma consistente y cuáles presentan tasas bajas de forma recurrente.

**Por sucursal:** Facilita la comparación entre centros de trabajo y la detección de ubicaciones con problemas operativos sistémicos.

**Por periodo:** Muestra la evolución de la completitud a lo largo del tiempo. Una tasa decreciente puede indicar exceso de carga de trabajo, falta de claridad en las instrucciones o problemas de supervisión.

---

### Tareas completadas a tiempo vs. vencidas

Este indicador desglosa las tareas completadas en dos grupos: las que se terminaron antes de la fecha límite y las que se terminaron después de vencer. También incluye las tareas que vencieron y no llegaron a completarse.

La proporción entre tareas a tiempo y vencidas es un indicador directo de la capacidad del equipo para cumplir los plazos operativos. Una tasa alta de vencimientos puede señalar que los plazos están mal calibrados, que la carga de trabajo es excesiva o que la priorización interna del equipo no es la adecuada.

---

### Tiempo medio de resolución

El tiempo medio de resolución es la diferencia promedio entre la fecha de asignación y la fecha de completitud de las tareas. Se puede filtrar por tipo de tarea, por empleado o por sucursal.

Este indicador es especialmente útil para calibrar los plazos de futuras tareas similares. Si el tiempo medio de resolución de las tareas de mantenimiento es sistemáticamente mayor que el plazo asignado, es una señal clara de que los plazos deben ajustarse o que el equipo necesita más recursos.

---

### Tasa de rechazo

Mide el porcentaje de tareas que, una vez marcadas como completadas por el empleado, fueron rechazadas por el responsable. Una tasa de rechazo alta sobre un empleado concreto puede indicar problemas de comprensión de las instrucciones o de estándares de calidad. Una tasa de rechazo alta generalizada puede señalar que las instrucciones de las tareas no son suficientemente claras.

---

### Valoraciones medias de desempeño

Si el sistema de valoración está activo, los informes incluyen la puntuación media por empleado, por tipo de tarea y por periodo. Esta métrica complementa la tasa de completitud: un empleado puede completar muchas tareas a tiempo pero con una calidad de ejecución baja, o completar pocas tareas pero con valoraciones excelentes.

---

## Filtros disponibles

Todos los informes pueden segmentarse por:

- **Periodo de tiempo:** Diario, semanal, mensual o rango de fechas personalizado.
- **Empleado:** Un empleado concreto o todos los empleados.
- **Sucursal:** Una sucursal específica o toda la entidad.
- **Tipo de tarea:** Mantenimiento, formación, operativo, etc.
- **Prioridad:** Alta, media o baja.
- **Estado:** Completadas, vencidas, rechazadas, validadas.

---

## Exportación de datos

Los informes pueden exportarse en formato Excel o CSV desde el botón **Exportar** que aparece en cada informe. El archivo descargado incluye una fila por tarea con todos los campos relevantes: título, empleado, fechas, estado, prioridad, número de rechazos y valoración.

> **Nota:** La exportación respeta los filtros activos en el momento de pulsar el botón. Asegúrese de configurar el filtro deseado antes de exportar para obtener exactamente los datos que necesita.

---

## Uso de los informes para evaluación de desempeño

Los datos del módulo de tareas son una fuente objetiva para las evaluaciones periódicas de desempeño. A diferencia de las valoraciones subjetivas, las métricas de completitud, cumplimiento de plazos y puntuaciones acumuladas ofrecen evidencia cuantitativa del rendimiento de cada empleado.

En una evaluación trimestral, por ejemplo, puede combinar los datos de tareas con los del control horario para obtener una imagen completa: el empleado A tiene alta puntualidad pero baja completitud de tareas; el empleado B completa todas sus tareas pero con frecuentes rechazos previos. Cada perfil requiere una conversación y un plan de acción diferente.

---

## Planificación operativa basada en datos

Los informes de tareas también son útiles para optimizar la operativa futura. Analizando el tiempo medio de resolución por tipo de tarea, puede asignar plazos más realistas. Comparando la tasa de completitud entre sucursales, puede detectar qué centros necesitan más supervisión o formación. Identificando los tipos de tarea con mayor tasa de rechazo, puede mejorar las instrucciones o crear plantillas de tarea más detalladas.

> **Consejo:** Revise los informes de tareas al menos una vez al mes. Quince minutos de análisis mensual son suficientes para detectar tendencias antes de que se conviertan en problemas consolidados.

---

## Artículos relacionados

| Artículo | Descripción |
|---|---|
| [Valoración del trabajador](./46-valoracion-del-trabajador.md) | Cómo se generan las puntuaciones de desempeño |
| [Prioridades y fechas límite](./44-prioridades-y-fechas-limite.md) | Configuración de plazos que afectan a los informes |
| [Estados de una tarea](./42-estados-de-una-tarea.md) | Significado de los estados reflejados en los informes |
| [Validación de tareas](./45-validacion-de-tareas.md) | Relación entre validaciones y métricas |
| [Qué es el módulo de tareas](./39-que-es-el-modulo-de-tareas.md) | Visión general del módulo |
