# Exportar a Excel y CSV

CheckBiz360 permite exportar los informes generados en dos formatos estándar: Excel (.xlsx) y CSV. Esta guía describe los pasos para realizar la exportación, los campos que contiene cada archivo y las consideraciones prácticas y legales que debe tener en cuenta al compartir o utilizar los datos exportados.

---

## Formatos de exportación disponibles

### Excel (.xlsx)

El formato Excel produce un archivo compatible con Microsoft Excel, LibreOffice Calc y cualquier herramienta de hoja de cálculo que admita el estándar Open XML. El archivo incluye:

- Hoja principal con los datos del informe en formato tabular.
- Fila de encabezado con los nombres de cada columna.
- Formato de celdas aplicado para fechas y horas (no se exportan como texto plano).
- Totales y subtotales en filas resumen al final de cada bloque de datos cuando el informe los incluye.

Este formato es el recomendado cuando va a trabajar con el archivo directamente en una hoja de cálculo o cuando necesita presentarlo con formato legible.

### CSV (UTF-8, separador punto y coma)

El formato CSV produce un archivo de texto plano que puede ser importado por la mayoría de los programas de gestión de nóminas, ERPs y herramientas de análisis de datos.

Características del CSV exportado:

- Codificación **UTF-8** con BOM para garantizar la correcta visualización de caracteres especiales (tildes, ñ) en Excel y otros programas.
- Separador de campos: **punto y coma (;)**.
- Separador decimal: **coma (,)** según el estándar español.
- Valores de texto entrecomillados con comillas dobles cuando contienen el separador o saltos de línea.

> **Aviso:** Si importa el archivo CSV en un software que utilice coma como separador de campos, deberá ajustar la configuración de importación de ese programa o convertir el archivo previamente. Esta es la configuración estándar en España; si trabaja con herramientas configuradas para el mercado anglosajón, consulte a su proveedor de software.

---

## Pasos para exportar un informe

1. Acceda al módulo de **Informes** en el backoffice.
2. Configure los filtros del informe que desea exportar (tipo, fechas, empleado, sucursal).
3. Pulse **Previsualizar** para verificar que los datos son correctos.
4. Una vez confirmada la previsualización, pulse **Exportar**.
5. Seleccione el formato: **Excel (.xlsx)** o **CSV**.
6. El archivo se descargará automáticamente en la carpeta de descargas de su navegador.

---

## Campos incluidos en la exportación de asistencia

La exportación del informe de asistencia incluye las siguientes columnas:

| Campo | Descripción |
|---|---|
| ID empleado | Identificador único del empleado en la plataforma |
| Nombre | Nombre completo del empleado |
| Sucursal | Sucursal a la que está asignado el empleado |
| Fecha | Fecha del registro (formato DD/MM/AAAA) |
| Hora de entrada | Timestamp del fichaje de entrada |
| Hora de salida | Timestamp del fichaje de salida |
| Horas trabajadas | Total de horas y minutos de la jornada registrada |
| Estado | Completa, ausencia justificada, ausencia no justificada, jornada parcial |
| Corrección manual | Indica si algún dato fue modificado manualmente por un responsable |
| Código de error | Código del error detectado si el fichaje presentó alguna anomalía; en blanco si no hay error |

---

## Usos prácticos de la exportación

### Importación en software de nóminas

La mayoría de los programas de gestión de nóminas (A3nom, Sage, Nominaplus, etc.) admiten la importación de datos de presencia en formato CSV. Consulte la documentación de su software para conocer el mapeo exacto de campos requerido. El CSV de CheckBiz360 incluye todos los campos habituales que estos programas solicitan.

### Entrega a gestoría

Si la gestión laboral de su empresa está externalizada, puede exportar el informe mensual de asistencia en Excel y enviarlo directamente a su gestoría. El formato Excel es preferible en este caso porque incluye el formato de celda y los totales ya calculados, lo que reduce el trabajo manual del gestor.

### Auditorías de recursos humanos

En un proceso de auditoría interna o externa de RRHH, los registros de asistencia exportados desde CheckBiz360 sirven como evidencia documental de la gestión de la jornada laboral. El campo de corrección manual y el campo de código de error ofrecen trazabilidad adicional sobre la calidad e integridad de los datos.

---

## Consideraciones RGPD al exportar datos de empleados

Los archivos exportados contienen datos personales de los empleados en el sentido del Reglamento General de Protección de Datos (RGPD). La empresa, como responsable del tratamiento, debe tener en cuenta lo siguiente al gestionar estos archivos:

- **Almacenamiento seguro.** Los archivos exportados deben guardarse en ubicaciones con acceso restringido. No deben almacenarse en carpetas compartidas sin control de acceso ni en servicios de almacenamiento en la nube sin cifrado o sin gestión de permisos.
- **Transmisión protegida.** Si envía el archivo por email a su gestoría u otros destinatarios externos, utilice canales cifrados o proteja el archivo con contraseña.
- **Minimización de datos.** Exporte solo los campos y el periodo de datos necesarios para cada finalidad concreta. No distribuya exportaciones completas cuando solo se necesita un subconjunto de datos.
- **Registro de actividades.** Si su empresa está obligada a mantener un registro de actividades de tratamiento conforme al artículo 30 del RGPD, la exportación y transmisión de datos de empleados debe estar documentada en dicho registro.
- **Periodo de conservación.** Los archivos exportados deben eliminarse una vez cumplida su finalidad, salvo que exista una obligación legal de conservarlos (como el periodo de cuatro años del registro de jornada).

> **Aviso:** CheckBiz360 mantiene los datos originales almacenados en la plataforma con las medidas de seguridad exigidas por la normativa aplicable. Una vez que los datos se exportan y salen de la plataforma, la seguridad de esos archivos es responsabilidad de su empresa.

---

> **Nota:** El acceso a la función de exportación requiere rol de Owner o Manager. Los supervisores pueden visualizar informes en pantalla si el manager les ha concedido ese permiso, pero no pueden exportar archivos.

---

## Artículos relacionados

| Artículo | Descripción |
|---|---|
| [Tipos de informe disponibles](./76-tipos-de-informe.md) | Qué contiene cada tipo de informe y quién puede acceder |
| [Generar y filtrar informes](./77-generar-y-filtrar-informes.md) | Pasos para generar un informe con filtros personalizados |
| [Informe de cumplimiento normativo](./79-informe-de-cumplimiento-normativo.md) | El informe para el RDL 8/2019 |
| [Conservación y protección de datos](../12-cumplimiento-normativo/83-conservacion-y-proteccion-de-datos.md) | Base legal y derechos de los empleados sobre sus datos |
