# Informes automáticos

CheckBiz360 permite configurar informes que se generan y envían por email de forma periódica, sin necesidad de que ningún responsable tenga que acceder al backoffice para solicitarlos manualmente. Esta guía explica cómo activar, configurar, modificar y desactivar un informe automático.

---

## Qué es un informe automático

Un informe automático es una tarea programada que ejecuta la generación de un informe en la frecuencia que usted configure y envía el resultado por email a los destinatarios definidos. El contenido, el alcance y la frecuencia son configurables de forma independiente para cada informe.

Puede tener varios informes automáticos activos simultáneamente, cada uno con una configuración distinta.

---

## Frecuencias disponibles

| Frecuencia | Descripción | Día de envío |
|---|---|---|
| Diario | Se genera cada día laborable | El mismo día, a la hora configurada |
| Semanal | Se genera una vez a la semana | El día de la semana que usted seleccione |
| Mensual | Se genera una vez al mes | El primer día hábil del mes siguiente |

> **Aviso:** Los informes automáticos con frecuencia diaria solo se ejecutan los días laborables según el calendario de la entidad. Los fines de semana y los días festivos configurados en el sistema no se genera ni se envía el informe.

---

## Destinatarios del informe

Puede configurar uno o varios destinatarios para cada informe automático:

- **Manager:** cualquier usuario con rol de Manager en su entidad recibirá el informe en su dirección de email registrada en la plataforma.
- **Owner:** el propietario de la entidad.
- **Dirección de email externa:** puede añadir una o varias direcciones de correo externas para que la gestoría, el departamento financiero u otros responsables externos reciban el informe directamente, sin necesidad de tener acceso al backoffice.

> **Nota:** Los destinatarios externos reciben el informe como archivo adjunto en el email, pero no obtienen ningún acceso a la plataforma. El email incluye el nombre de la entidad y el periodo cubierto en el asunto del mensaje.

---

## Contenido configurable

Para cada informe automático puede elegir qué tipo de informe se genera:

### Informe de asistencia semanal del equipo

Incluye el resumen de presencias, ausencias y horas trabajadas de todos los empleados de la sucursal o sucursales seleccionadas durante la semana. Es el informe más habitual para el seguimiento operativo semanal del manager.

### Resumen mensual de costes

Incluye el coste total de las horas trabajadas por empleado y por sucursal durante el mes. Se envía el primer día hábil del mes siguiente con los datos del mes cerrado. Solo puede configurarlo un Owner o un Manager con acceso al informe de costes.

### Alerta diaria de ausencias no justificadas

Genera y envía cada mañana un listado de los empleados que tenían turno el día anterior y no registraron entrada ni han justificado su ausencia. Permite al manager actuar con rapidez ante ausencias no comunicadas.

---

## Cómo activar un informe automático

1. Acceda al backoffice con un rol de Owner o Manager.
2. Vaya a la sección **Informes** y seleccione la pestaña **Informes automáticos**.
3. Pulse **Nuevo informe automático**.
4. Seleccione el tipo de informe que desea programar.
5. Seleccione la frecuencia: diario, semanal o mensual.
6. Si selecciona frecuencia semanal, elija el día de la semana en que debe enviarse.
7. Seleccione el alcance: sucursal concreta o todas las sucursales.
8. Añada los destinatarios: roles internos o direcciones de email externas.
9. Pulse **Guardar y activar**.

El informe comenzará a ejecutarse en el siguiente ciclo programado.

---

## Cómo modificar un informe automático existente

1. Vaya a **Informes > Informes automáticos**.
2. Localice el informe en la lista de informes activos.
3. Pulse el icono de edición junto al informe.
4. Modifique los parámetros que desee: frecuencia, destinatarios, alcance o tipo.
5. Pulse **Guardar cambios**.

Los cambios se aplican al siguiente ciclo de ejecución. Si el informe ya se ha enviado en el ciclo actual, el cambio no lo regenera retroactivamente.

---

## Cómo desactivar un informe automático

1. Vaya a **Informes > Informes automáticos**.
2. Localice el informe en la lista.
3. Desactive el interruptor de estado junto al nombre del informe, o pulse **Eliminar** si no desea conservar la configuración.

La desactivación es inmediata. El sistema no enviará el informe en los ciclos siguientes hasta que se reactive.

> **Aviso:** Desactivar un informe automático no elimina los informes ya enviados ni los datos históricos. Solo detiene las ejecuciones futuras.

---

> **Nota:** La configuración de informes automáticos está disponible únicamente para los roles de Owner y Manager. No es posible que un supervisor o un trabajador configure o reciba informes automáticos a través de la plataforma.

---

## Artículos relacionados

| Artículo | Descripción |
|---|---|
| [Tipos de informe disponibles](./76-tipos-de-informe.md) | Qué contiene cada tipo de informe |
| [Generar y filtrar informes](./77-generar-y-filtrar-informes.md) | Generación manual de informes con filtros |
| [Exportar a Excel y CSV](./78-exportar-a-excel-y-csv.md) | Formatos de exportación disponibles |
| [Informe de cumplimiento normativo](./79-informe-de-cumplimiento-normativo.md) | El informe para la Inspección de Trabajo |
