# Validación del empleado mediante QR

Antes de que un empleado pueda registrar su primer fichaje del día, CheckBiz360 puede requerir un paso previo de verificación de identidad. Este proceso, conocido como validación del empleado, utiliza un código QR generado en la app del empleado que el supervisor escanea para confirmar que la persona presente es quien dice ser. Este artículo explica cuándo se aplica, cómo funciona y qué representa desde el punto de vista técnico.

---

## Qué es la validación del empleado

La validación del empleado es un mecanismo de verificación presencial de identidad que se produce antes del primer fichaje de la jornada. Su propósito es garantizar que es el propio empleado quien está presente en el momento del fichaje, añadiendo una capa adicional de seguridad frente al registro delegado o fraudulento.

Este proceso es configurable: no todas las sucursales o entidades requieren validación QR. Cuando está habilitada, el empleado no puede completar el fichaje hasta que el supervisor haya escaneado y validado su código.

---

## El token de validación

Cuando el empleado inicia sesión en la app y selecciona su entidad de trabajo, el sistema genera un **token de validación del empleado** (`tokenValidateEmployee`). Este token es una cadena en formato base64 que contiene el identificador del empleado (`employeeId`) y el identificador de la entidad (`entityId`).

El token tiene una vigencia limitada y se utiliza exclusivamente para el proceso de validación QR. No es reutilizable entre sesiones ni transferible entre dispositivos.

---

## El código QR

A partir del token de validación, la app genera un código QR visible en la pantalla del dispositivo del empleado. Este código contiene la información necesaria para que el sistema identifique al empleado de forma inequívoca.

El supervisor, utilizando su propio dispositivo con la app de CheckBiz360, escanea este código QR. El sistema verifica el token, confirma la identidad del empleado y marca la validación como completada.

---

## Flujo completo del proceso

1. El empleado abre la app de CheckBiz360 e inicia sesión con sus credenciales.
2. Selecciona la entidad de trabajo correspondiente.
3. Si la sucursal requiere validación QR, la app muestra la pantalla de validación con el código QR generado a partir del token.
4. El supervisor acude al empleado y escanea el QR desde su dispositivo.
5. El sistema verifica el token y registra la validación de identidad.
6. La app del empleado pasa automáticamente a la pantalla de fichaje.
7. El empleado puede ahora registrar su entrada con normalidad.

---

## Precalentamiento del sistema de fichaje

Cuando el supervisor escanea el código QR y completa la validación, el sistema ejecuta de forma automática y transparente un proceso de precalentamiento (*warm-up*) del entorno de fichaje. Este proceso prepara y verifica en segundo plano todos los parámetros necesarios para que el fichaje se procese de forma inmediata: turno activo, geocerca, configuración del dispositivo y estado del empleado.

El empleado no percibe este proceso. Desde su perspectiva, simplemente pasa de la pantalla de validación a la pantalla de fichaje. Sin embargo, este mecanismo mejora la velocidad y fiabilidad del registro, especialmente en entornos con muchos empleados fichando en el mismo intervalo de tiempo.

---

## Cuándo es necesaria la validación QR

La validación QR se activa según la configuración de la sucursal. Algunos escenarios habituales en los que se utiliza:

- Entornos con alta rotación de personal o contrataciones temporales donde la identidad del empleado puede no ser conocida por el supervisor.
- Instalaciones con control de acceso estricto donde se requiere verificación dual.
- Sectores con obligaciones normativas de identificación presencial (seguridad, sanidad, alimentación).
- Empresas que desean añadir una capa adicional de control sin necesidad de lectores biométricos físicos.

---

> **Aviso de privacidad:** El código QR contiene únicamente el identificador del empleado y el de la entidad, ambos en formato cifrado. No incluye datos personales en texto plano. El token expira tras su uso o al finalizar la sesión del empleado.

---

## Roles con acceso a esta funcionalidad

El empleado con rol **empleado** genera el QR desde su app. El escaneo y validación del código corresponde a usuarios con rol **supervisor**, **manager** u **owner**. La activación de la validación QR como requisito previo al fichaje es configurable por roles **manager** u **owner**.

---

## Artículos relacionados

- [Check-in y check-out desde la app](14-checkin-checkout-desde-app.md)
- [Cómo funciona el fichaje](13-como-funciona-el-fichaje.md)
- [Revisión y validación de fichajes](20-revision-y-validacion-de-fichajes.md)
- [Estados y códigos de error](22-estados-y-codigos-de-error.md)
