# Glosario de CheckBiz360

Este glosario recoge los términos técnicos y operativos más relevantes de CheckBiz360, ordenados alfabéticamente. Cada definición incluye el nombre en español, el término técnico utilizado en la plataforma cuando corresponde, y una descripción de su significado en el contexto del sistema.

---

## A

### Ajuste de timestamp (`adjustedTimestamp`)
Mecanismo opcional de la plataforma que modifica automáticamente la hora registrada en un fichaje para redondearla o aproximarla a un valor configurado. Por ejemplo, un checkin realizado a las 08:57 puede ajustarse a las 09:00 si la regla de ajuste está activa. El valor original del fichaje siempre queda registrado junto al valor ajustado para mantener la trazabilidad.

---

## B

### Biometría requerida (`biometricRequired`)
Configuración que obliga a un empleado a autenticarse mediante huella dactilar o reconocimiento facial antes de completar un fichaje desde la app móvil. Cuando está activa, el sistema no acepta el fichaje si la biometría no se verifica correctamente en el dispositivo.

---

## C

### Calendario efectivo
Configuración que define los días laborables y festivos para una sucursal o para un empleado concreto. El calendario efectivo determina qué días el sistema espera fichajes y qué días se consideran libres o festivos. Se configura desde el backoffice en la sección de calendarios.

### Checkin / Checkout
Registro de la hora de entrada (checkin) y de salida (checkout) de un empleado en su jornada laboral. Son los eventos fundamentales del control horario. Un checkin sin checkout correspondiente genera una jornada incompleta. Véase también: Fichaje / Checklog.

### Código de error
Identificador alfanumérico que el sistema devuelve cuando una operación no puede completarse. Los códigos de error siguen el formato `modulo/tipo_de_error` (por ejemplo, `checklog/out_of_radius`). Permiten identificar la causa exacta de un fallo sin necesidad de interpretar mensajes de texto. Véase el artículo [Códigos de error completos](./90-codigos-de-error-completos.md).

---

## D

### Dispositivo de confianza (`trustedDevice`)
Dispositivo móvil autorizado explícitamente por el Owner o el Manager para que un empleado concreto pueda realizar fichajes desde él. La plataforma puede configurarse para rechazar fichajes procedentes de dispositivos no registrados como de confianza.

---

## E

### Empleado / Employee
Usuario de CheckBiz360 con rol Worker, Supervisor o Manager que forma parte de la plantilla de una entidad. En la plataforma, el término "employee" hace referencia al registro de datos de una persona en la organización, incluyendo su perfil, asignaciones, fichajes y documentos.

### Entidad / Entity
La unidad organizativa raíz de CheckBiz360. Corresponde a una empresa o cliente que ha contratado la plataforma. Cada entidad puede tener múltiples sucursales, empleados y configuraciones propias. El Owner es el responsable máximo de la entidad.

### EmployeePattern
Análisis del comportamiento histórico de un empleado basado en sus registros de asistencia y productividad. El sistema genera patrones que permiten identificar regularidades, anomalías o tendencias en la jornada laboral de cada trabajador. Disponible en planes con módulo de inteligencia operativa.

---

## F

### Fichaje / Checklog
Registro individual de una acción de control horario realizada por un empleado. Un checklog incluye: tipo de evento (checkin, checkout, restin, restout), coordenadas GPS, timestamp, dispositivo utilizado y estado de validación. Es la unidad mínima de datos del módulo de control horario.

---

## G

### Geocerca / Radio de fichaje (`ratioChecklog`)
Perímetro geográfico circular definido alrededor de las coordenadas de una sucursal. Solo se aceptan fichajes realizados dentro de ese perímetro. El radio se mide en metros y se configura desde la ficha de cada sucursal en el backoffice.

---

## H

### Herencia de configuración
Mecanismo por el que los empleados o sucursales adoptan automáticamente la configuración definida en un nivel superior de la jerarquía (por ejemplo, de la entidad a la sucursal, o de la sucursal al empleado). Si un parámetro no está configurado explícitamente en el nivel inferior, el sistema utiliza el valor del nivel superior.

---

## I

### Índice de eficiencia (`efficiencyIndex`)
Métrica calculada por el módulo de inteligencia operativa que mide el rendimiento operativo de un empleado en relación con sus horas trabajadas y tareas completadas. Se expresa como un valor numérico y permite comparar empleados o periodos de forma objetiva.

### Índice de fiabilidad (`reliabilityScore`)
Puntuación que refleja la consistencia y regularidad del comportamiento de fichaje de un empleado a lo largo del tiempo. Un índice alto indica que el empleado ficha de forma puntual y consistente. Un índice bajo puede señalar irregularidades que merecen atención. Disponible en el módulo de inteligencia operativa.

---

## J

### Jornada incompleta (`incomplete_workday`)
Jornada laboral en la que existe un checkin pero no el checkout correspondiente, o viceversa. El sistema la marca automáticamente como incompleta y la excluye del cálculo de horas trabajadas hasta que se completa mediante una jornada manual.

### Jornada manual
Corrección retroactiva de un fichaje realizada por un Owner o Manager desde el backoffice. Se utiliza cuando un empleado olvidó fichar, cuando el sistema no pudo registrar el evento por un fallo técnico puntual o cuando es necesario ajustar datos de asistencia históricos. Queda registrada con el nombre del usuario que la realizó y la fecha de la modificación.

---

## M

### Manager
Rol de usuario con capacidad para gestionar empleados, sucursales, documentos, informes e incidencias dentro de las sucursales que le han sido asignadas. El Manager actúa bajo la supervisión del Owner y no puede modificar la configuración global de la entidad.

### Módulo documental
Conjunto de funcionalidades de CheckBiz360 que permite subir, organizar, asignar y firmar documentos laborales (contratos, nóminas, comunicados, políticas de empresa). Los empleados pueden firmar digitalmente los documentos desde la app móvil. Disponible en planes premium.

---

## N

### Notificación push
Mensaje enviado directamente al dispositivo móvil de un empleado a través del sistema de notificaciones del sistema operativo (APNs en iOS, FCM en Android). CheckBiz360 utiliza notificaciones push para avisar de nuevas tareas, documentos pendientes de firma, alertas de jornada y comunicados del sistema.

---

## O

### Owner
Rol con acceso completo a todas las funcionalidades de una entidad en CheckBiz360. El Owner puede gestionar empleados, sucursales, configuración global, facturación y todos los módulos disponibles en el plan contratado. Cada entidad tiene al menos un Owner.

---

## P

### Pausa (`restin` / `restout`)
Registro del inicio (`restin`) y fin (`restout`) de una pausa dentro de la jornada laboral. Las pausas se descontarán o no del tiempo trabajado según la configuración de la sucursal. Al igual que el checkin y checkout, las pausas requieren que el empleado esté dentro de la geocerca si así está configurado.

### Plan de suscripción
Nivel de contratación de CheckBiz360 que determina qué módulos y funcionalidades están disponibles para una entidad. Los planes disponibles son: base, avanzado, premium y empresarial. Véase [Planes y funcionalidades](./91-planes-y-funcionalidades.md).

### Puntuación de promoción (`promotionScore`)
Métrica del módulo de inteligencia operativa que combina varios indicadores de rendimiento (fiabilidad, eficiencia, puntualidad, resolución de tareas) para generar una puntuación global orientada a facilitar decisiones de desarrollo profesional o reconocimiento de empleados.

---

## R

### RDL 8/2019
Real Decreto-ley 8/2019, de 8 de marzo, que establece la obligación de registro horario para todos los trabajadores en España. CheckBiz360 está diseñado para cumplir con los requisitos de este decreto, proporcionando registros inmutables, con hora exacta y disponibles para inspección laboral.

### Registro de jornada
Conjunto de todos los eventos de fichaje (checkin, restin, restout, checkout) que componen una jornada laboral completa de un empleado. El registro de jornada es la unidad de análisis para el cálculo de horas, el cumplimiento normativo y la generación de informes.

### Responsabilidades (`responsibilities`)
Campo de configuración de un empleado que define las áreas de trabajo o funciones específicas que tiene asignadas dentro de la organización. Las responsabilidades pueden utilizarse para la asignación de tareas y como criterio de filtrado en informes.

### Rol
Nivel de acceso y permisos de un usuario dentro de CheckBiz360. Los roles disponibles son: Owner, Manager, Supervisor y Worker. Cada rol tiene un conjunto definido de acciones que puede realizar en el backoffice y en la app móvil.

---

## S

### Sucursal / Branch
Unidad organizativa dentro de una entidad que representa un centro de trabajo, una delegación o cualquier agrupación geográfica o funcional de empleados. Cada sucursal tiene sus propias coordenadas, radio de fichaje, horarios, calendario efectivo y configuración de control horario.

### Supervisor
Rol intermedio entre Manager y Worker. El Supervisor puede revisar los fichajes y tareas de los empleados de su equipo directo si el Manager le ha concedido esa capacidad, pero no tiene acceso a la configuración global de la sucursal ni a los informes de costes o anomalías.

---

## T

### Token de validación
Código temporal generado por el sistema para verificar la identidad de un usuario en operaciones sensibles, como el primer inicio de sesión, el restablecimiento de contraseña o la autorización de un nuevo dispositivo. Los tokens de validación caducan pasado un tiempo determinado.

### Trabajo remoto (`enableRemoteWork`)
Configuración que permite a un empleado realizar fichajes desde una ubicación diferente a la geocerca de su sucursal. Cuando está activa, el sistema acepta fichajes fuera del radio habitual sin generar el error `checklog/out_of_radius`. Debe activarse explícitamente por el Owner o Manager.

### Turno
Franja horaria asignada a un empleado para una jornada concreta, que define su hora de inicio y fin de trabajo esperados. Los turnos se configuran en el backoffice y se asocian al calendario efectivo del empleado o la sucursal.

---

## W

### Worker
Rol de usuario base en CheckBiz360, correspondiente a un empleado operativo. Los Workers pueden fichar desde la app, consultar sus propios datos de asistencia, ver sus documentos y gestionar sus tareas. No tienen acceso al backoffice salvo que se les conceda un rol superior.

---

## Nota de rol

Este artículo es de consulta libre para todos los roles de la plataforma: Owner, Manager, Supervisor y Worker.

---

## Artículos relacionados

| Artículo | Descripción |
|---|---|
| [Codigos de error completos](./90-codigos-de-error-completos.md) | Referencia de todos los códigos de error del sistema |
| [Planes y funcionalidades](./91-planes-y-funcionalidades.md) | Descripción de módulos disponibles por nivel de plan |
| [Preguntas frecuentes](./92-preguntas-frecuentes.md) | Respuestas a las dudas más habituales sobre CheckBiz360 |
| [Control horario: conceptos básicos](../03-control-horario/20-como-funciona-el-control-horario.md) | Introducción al módulo de control horario |
