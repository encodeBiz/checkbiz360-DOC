# Planes y funcionalidades de CheckBiz360

CheckBiz360 está organizado en módulos funcionales que se activan según el nivel de plan contratado. Esta estructura permite que cada empresa acceda únicamente a las herramientas que necesita, con la posibilidad de ampliar sus capacidades en cualquier momento desde el backoffice. Este artículo describe qué incluye cada módulo y en qué plan se encuentra disponible.

---

## Estructura modular de la plataforma

CheckBiz360 se organiza en cuatro niveles de plan, cada uno de los cuales incluye todos los módulos del nivel anterior más las funcionalidades propias del nivel:

- **Plan Base**
- **Plan Avanzado**
- **Plan Premium**
- **Plan Empresarial**

A continuación se describe en detalle qué funcionalidades componen cada módulo.

---

## Plan Base — Control horario y gestión operativa esencial

El plan base es el punto de partida de CheckBiz360. Cubre las necesidades fundamentales de cualquier empresa que deba cumplir con la obligación de registro horario establecida por el RDL 8/2019.

### Control horario y fichajes

- Registro de checkin y checkout desde la app móvil (iOS y Android).
- Validación de fichajes por geolocalización: geocerca configurable por sucursal.
- Soporte para pausas (`restin` / `restout`).
- Ajuste automático de timestamp con configuración de reglas.
- Historial de fichajes con trazabilidad completa e inmutable.
- Detección de jornadas incompletas.
- Jornadas manuales para corrección retroactiva de registros.
- Trabajo remoto: opción de permitir fichajes fuera de la geocerca habitual.

### Gestión de empleados

- Alta, baja y modificación de perfiles de empleado.
- Asignación de roles: Owner, Manager, Supervisor, Worker.
- Gestión de dispositivos de confianza.
- Configuración de biometría requerida por empleado.
- Asignación de sucursales y responsabilidades.
- Envío de invitación de bienvenida y gestión de credenciales.

### Gestión de sucursales y calendarios

- Creación y configuración de sucursales con coordenadas y radio de fichaje.
- Herencia de configuración desde entidad a sucursal y de sucursal a empleado.
- Calendarios efectivos con soporte para festivos y excepciones.
- Configuración de horarios y turnos por sucursal.
- Gestión de la zona horaria por sucursal.

### Informes básicos

- Informe de asistencia: presencias, ausencias y horas trabajadas por empleado y periodo.
- Informe de puntualidad: tardanzas, salidas anticipadas y desviaciones de horario.
- Exportación de datos a CSV y PDF.
- Acceso a datos históricos dentro del periodo de retención del plan.

### Módulo de tareas

- Creación y asignación de tareas a empleados.
- Seguimiento del estado de las tareas: pendiente, en curso, completada, rechazada.
- Validación de tareas por el manager con valoración opcional.
- Notificaciones push de nuevas tareas y recordatorios.

---

## Plan Avanzado — Inteligencia operativa

El plan avanzado incluye todo lo del plan base más el módulo de inteligencia operativa, diseñado para empresas que quieren pasar de la supervisión reactiva al análisis predictivo de su equipo.

### Inteligencia operativa

- **EmployeePattern**: análisis del comportamiento histórico de fichajes y productividad por empleado. Identifica regularidades, anomalías y tendencias en la jornada laboral.
- **reliabilityScore (índice de fiabilidad)**: puntuación que mide la consistencia del comportamiento de fichaje de cada empleado a lo largo del tiempo.
- **efficiencyIndex (índice de eficiencia)**: métrica que combina horas trabajadas y tareas completadas para evaluar el rendimiento operativo.
- **promotionScore (puntuación de promoción)**: indicador global que agrega fiabilidad, eficiencia, puntualidad y resolución de tareas para apoyar decisiones de desarrollo profesional.
- **Análisis de costes**: cruce de datos de asistencia con información salarial para calcular el coste real por empleado, sucursal y periodo.
- **Detección de anomalías**: identificación automática de fichajes sospechosos por precisión temporal excesiva, geolocalización estática o procedencia de dispositivos no autorizados. Generación del informe de anomalías.
- **Informe de tareas**: métricas de desempeño basadas en tareas asignadas, completadas, vencidas y valoradas.

---

## Plan Premium — Gestión documental y cumplimiento normativo

El plan premium añade al plan avanzado las herramientas para la gestión completa del ciclo de vida de los documentos laborales y el cumplimiento normativo documentado.

### Gestión documental

- Subida, organización y categorización de documentos laborales: contratos, nóminas, comunicados, políticas de empresa, formación y otros tipos.
- Asignación de documentos a empleados individuales o grupos.
- Control de visibilidad: documentos públicos o privados por empleado.
- Firma electrónica de documentos directamente desde la app móvil.
- Seguimiento del estado de firma: pendiente, firmado, rechazado.
- Historial de versiones de documentos.
- Notificaciones push a los empleados cuando hay documentos pendientes de firma o lectura.

### Cumplimiento normativo

- Informe de cumplimiento normativo: registro de jornadas en el formato requerido por el RDL 8/2019 para su presentación ante la Inspección de Trabajo.
- Registros inmutables con hash de integridad para garantizar la no alteración de los datos.
- Informes de cumplimiento exportables en formato PDF oficial.

---

## Plan Empresarial — Escala y personalización

El plan empresarial está diseñado para grupos empresariales, franquicias o empresas con necesidades de personalización y escala que van más allá de lo que cubre el plan premium.

### Multi-entidad

- Gestión de múltiples empresas o entidades desde una sola cuenta de administración.
- Panel de control unificado con visión agregada de todas las entidades.
- Configuración independiente por entidad: planes, módulos, calendarios y permisos.

### Integraciones con software externo

- Conexión con sistemas de nóminas y recursos humanos mediante API.
- Exportación programada de datos hacia plataformas de terceros.
- Soporte para webhooks y eventos en tiempo real.

### Soporte dedicado

- Gestor de cuenta asignado para la configuración inicial y la gestión continua.
- Tiempos de respuesta prioritarios para cualquier tipo de incidencia.
- Sesiones de formación para el equipo de administración de la empresa.
- Revisiones periódicas del uso de la plataforma y recomendaciones de optimización.

---

## Cómo cambiar de plan

Si necesita acceder a funcionalidades de un plan superior, puede gestionar el cambio directamente desde el backoffice sin necesidad de contactar con soporte:

1. Inicie sesión en el backoffice con su cuenta de Owner.
2. Acceda a **Configuración** en el menú lateral izquierdo.
3. Seleccione **Suscripción**.
4. En la pantalla de suscripción verá su plan actual y las opciones disponibles para ampliar.
5. Seleccione el plan deseado y siga los pasos del proceso de actualización.
6. Los nuevos módulos estarán disponibles de forma inmediata una vez completado el proceso.

> **Aviso:** El cambio de plan a un nivel superior se aplica de forma inmediata. Si necesita reducir su plan a uno inferior, el cambio se aplica al inicio del siguiente periodo de facturación. Los datos generados con módulos premium no se eliminan al bajar de plan, pero dejarán de ser accesibles hasta que se vuelva a activar el módulo correspondiente.

---

## Nota de rol

La gestión del plan de suscripción es exclusiva del **Owner** de la entidad. Los Managers y otros roles no tienen acceso a la sección de suscripción en el backoffice.

---

## Artículos relacionados

| Artículo | Descripción |
|---|---|
| [Preguntas frecuentes](./92-preguntas-frecuentes.md) | Respuestas a las dudas más habituales sobre CheckBiz360 |
| [Glosario](./89-glosario.md) | Definición de los términos técnicos utilizados en la plataforma |
| [Informe de cumplimiento normativo](../11-informes-y-exportacion/79-informe-de-cumplimiento-normativo.md) | El informe para el RDL 8/2019 y la Inspección de Trabajo |
| [Gestión documental: introducción](../05-gestion-documental/40-introduccion-al-modulo-documental.md) | Primeros pasos en el módulo de documentos |
| [Inteligencia operativa: introducción](../07-inteligencia-operativa/50-introduccion-a-la-inteligencia-operativa.md) | Cómo funciona el módulo de análisis avanzado |
